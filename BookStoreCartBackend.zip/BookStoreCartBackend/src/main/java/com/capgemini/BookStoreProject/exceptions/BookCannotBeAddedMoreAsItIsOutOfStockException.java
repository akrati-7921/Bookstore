package com.capgemini.BookStoreProject.exceptions;

public class BookCannotBeAddedMoreAsItIsOutOfStockException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public BookCannotBeAddedMoreAsItIsOutOfStockException(String msg)
	{
		super(msg);
	}

}
