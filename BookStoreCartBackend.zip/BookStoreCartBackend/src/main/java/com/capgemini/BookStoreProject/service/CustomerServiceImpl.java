package com.capgemini.BookStoreProject.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Cart;
import com.capgemini.BookStoreProject.beans.Review;
import com.capgemini.BookStoreProject.dao.IBookDAO;
import com.capgemini.BookStoreProject.dao.ICartDAO;
import com.capgemini.BookStoreProject.dao.CartDAOImpl;
import com.capgemini.BookStoreProject.dao.IReviewDao;
import com.capgemini.BookStoreProject.exceptions.BookCannotBeAddedMoreAsItIsOutOfStockException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.NoBookInTheCartException;

@org.springframework.stereotype.Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	IBookDAO bookDAO;
	
	@Autowired
	IReviewDao reviewDAO;
	
	ICartDAO customerCartMgmt = new CartDAOImpl();
	
	@Override
	public String clearCart() {
		customerCartMgmt.clearCart();
		return "Cart cleared successfully";
	}

	@Override
	public Map<Integer,Cart> addABookToCart(Book book) {
		Cart cart = customerCartMgmt.searchBook(book.getBookId());
		if(cart==null)
		{
			customerCartMgmt.addABookToCart(book);
			return customerCartMgmt.showAll();
		}
		else
		{
			cart.setQuantity(cart.getQuantity()+1);
			return customerCartMgmt.showAll();
		}
	}

	@Override
	public Map<Integer, Cart> removeABookFromCart(int cartId) throws BookDoesNotExistException {
		Cart cart = customerCartMgmt.searchBook(cartId);
		if(cart!=null)
		{
			customerCartMgmt.removeABookFromCart(cartId);
			return customerCartMgmt.showAll();
		}
		else
			throw new BookDoesNotExistException("This book does not exist in your cart");
		
	}

	@Override
	public Map<Integer, Cart> addQuantityOfBook(int cartId) throws BookCannotBeAddedMoreAsItIsOutOfStockException {
		Book bookSearch = bookDAO.findById(cartId).get();
		if((bookSearch.getQuantity()-1)>=0)
		{
			bookSearch.setQuantity(bookSearch.getQuantity()-1);
			customerCartMgmt.addQuantityOfABook(cartId);
			return customerCartMgmt.showAll();
		}
		else
			throw new BookCannotBeAddedMoreAsItIsOutOfStockException("No more quantity of this Book can be added as it has become OUT OF STOCK");
	}

	@Override
	public Map<Integer,Cart> decreaseQuantityOfBook(int cartId) {
		Book bookSearch = bookDAO.findById(cartId).get();
		Cart cart = customerCartMgmt.searchBook(cartId);
		if((cart.getQuantity()-1)==0)
		{
			bookSearch.setQuantity(bookSearch.getQuantity()+1);
			customerCartMgmt.decreaseQuantityOfABook(cartId);
			return customerCartMgmt.showAll();
		}
		else
			{customerCartMgmt.decreaseQuantityOfABook(cartId);
			return customerCartMgmt.showAll();
			}
	}


	@Override
	public Map<Integer, Cart> showCart() throws NoBookInTheCartException {
		Map<Integer,Cart> bookCart = customerCartMgmt.showAll();
		if(bookCart.size()>0)
		{
		return customerCartMgmt.showAll();
		}
		else
			throw new NoBookInTheCartException("There is no book in the cart");
	}
	
	public double cartTotal() throws NoBookInTheCartException
	{
		if(customerCartMgmt.cartTotalPrice()==0)
			throw new NoBookInTheCartException("There is no book in the cart");
		else
			return customerCartMgmt.cartTotalPrice();
	}

	@Override
	public List<Review> bookReview(int bookId) {
		 Book book1=bookDAO.findById(bookId).get();
		 List<Review> li = new ArrayList<>();
		
			 li = reviewDAO.findByBook(book1);
			 return li;
			 
	}

	@Override
	public List<Review> saveReviews(Review review,int bookId) throws BookDoesNotExistException {
		if(bookDAO.existsById(bookId))
		{
			reviewDAO.save(review);
			return reviewDAO.findAll();
		}
		else 
			throw new BookDoesNotExistException("This book does not exist");
	}
}
