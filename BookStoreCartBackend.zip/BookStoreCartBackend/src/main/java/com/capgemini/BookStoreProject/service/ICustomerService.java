package com.capgemini.BookStoreProject.service;

import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Cart;
import com.capgemini.BookStoreProject.beans.Review;
import com.capgemini.BookStoreProject.exceptions.BookCannotBeAddedMoreAsItIsOutOfStockException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.NoBookInTheCartException;

@Service
public interface ICustomerService {

	
	public String clearCart();
	
	public Map<Integer, Cart> addABookToCart(Book book);
	
	public Map<Integer, Cart> removeABookFromCart(int cartId) throws BookDoesNotExistException;
	
	public Map<Integer, Cart> addQuantityOfBook(int cartId) throws BookCannotBeAddedMoreAsItIsOutOfStockException;
	
	public Map<Integer, Cart> decreaseQuantityOfBook(int cartId);
		
	public Map<Integer, Cart> showCart() throws NoBookInTheCartException;
	
	List<Review> bookReview(int reviewId);

	List<Review> saveReviews(Review reviews, int bookId) throws BookDoesNotExistException;
}
