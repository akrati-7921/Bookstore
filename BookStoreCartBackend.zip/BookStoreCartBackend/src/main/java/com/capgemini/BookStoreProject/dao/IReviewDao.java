package com.capgemini.BookStoreProject.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Review;


public interface IReviewDao extends JpaRepository<Review, Integer>{
	
	List<Review> findByBook(Book book);


}
