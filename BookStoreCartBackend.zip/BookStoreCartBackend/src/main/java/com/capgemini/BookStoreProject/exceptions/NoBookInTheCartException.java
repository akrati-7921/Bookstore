package com.capgemini.BookStoreProject.exceptions;

public class NoBookInTheCartException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoBookInTheCartException(String args) {
		super(args);
		// TODO Auto-generated constructor stub
	}
	
}
