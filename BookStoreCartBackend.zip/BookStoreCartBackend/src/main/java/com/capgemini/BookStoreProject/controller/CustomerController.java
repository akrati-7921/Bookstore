package com.capgemini.BookStoreProject.controller;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Cart;
import com.capgemini.BookStoreProject.beans.Orders;
import com.capgemini.BookStoreProject.beans.RegisterCustomer;
import com.capgemini.BookStoreProject.beans.Review;
import com.capgemini.BookStoreProject.exceptions.BookCannotBeAddedMoreAsItIsOutOfStockException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.NoBookInTheCartException;
import com.capgemini.BookStoreProject.service.CustomerServiceImpl;

@RestController
public class CustomerController {

	@Autowired
	CustomerServiceImpl customerService;
	
	
	@RequestMapping(value="/")
	public String home()
	{
		return "home";
	}
	
	@RequestMapping(value="/clearCart",method=RequestMethod.GET)
	public String clearCart()
	{
		return customerService.clearCart();
	}
	
	@RequestMapping(value="/addABookToCart",method=RequestMethod.PUT)
	public Map<Integer,Cart> addABookToCart(@RequestBody Book book)
	{
		return customerService.addABookToCart(book);
	}
	
	@RequestMapping(value="/removeABookFromCart/{id}",method=RequestMethod.DELETE)
	public Map<Integer,Cart> removeABookFromCart(@PathVariable int id) throws BookDoesNotExistException, NoBookInTheCartException
	{
		if(customerService.showCart().size()==1)
			{
			customerService.removeABookFromCart(id);

			}
		else
			return customerService.removeABookFromCart(id);
		return null;
	}

	@RequestMapping(value="/addQuantityOfBook/{cartId}",method=RequestMethod.GET)
	public Map<Integer,Cart> addQuantityOfBook(@PathVariable int cartId) throws BookCannotBeAddedMoreAsItIsOutOfStockException
	{
		return customerService.addQuantityOfBook(cartId);
	}
	
	@RequestMapping(value="/decreaseQuantityOfBook/{id}",method=RequestMethod.GET)
	public Map<Integer,Cart> decreaseQuantityOfBook(@PathVariable int id)
	{
		return customerService.decreaseQuantityOfBook(id);
	}
	
	@RequestMapping(value="/showCart",method=RequestMethod.GET)
	public Map<Integer,Cart> showCart() throws NoBookInTheCartException
	{
		return customerService.showCart();
	}
	
	@RequestMapping(value="/calculateCartTotal",method=RequestMethod.GET)
	public double calculateCartTotal() throws NoBookInTheCartException
	{
		return customerService.cartTotal();
	}
	
	@RequestMapping(value="/booksReview/{reviewId}",method=RequestMethod.GET) 
	public List<Review> reviewOfPerticularBook(@PathVariable int reviewId)
	{
		return customerService.bookReview(reviewId);
		
	}
	
	@RequestMapping(value = "/saveReview/{bookId}", method = RequestMethod.PUT)
	public List<Review> saveReviews(@RequestBody Review reviews,@PathVariable int bookId) throws BookDoesNotExistException {
			return customerService.saveReviews(reviews,bookId);
	} 	
}