package com.capgemini.BookStoreProject.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import com.capgemini.BookStoreProject.exceptions.BookCannotBeAddedMoreAsItIsOutOfStockException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.BookIdDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.NoBookInTheCartException;

@ControllerAdvice
public class BookStoreExceptionHandler  extends ResponseEntityExceptionHandler {

	@ExceptionHandler(value = BookCannotBeAddedMoreAsItIsOutOfStockException.class)
	public ResponseEntity<Object> bookCannotBeAddedMoreAsItIsOutOfStockException(BookCannotBeAddedMoreAsItIsOutOfStockException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	

	@ExceptionHandler(value = BookDoesNotExistException.class)
	public ResponseEntity<Object> bookDoesNotExistException(BookDoesNotExistException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = NoBookInTheCartException.class)
	public ResponseEntity<Object> noBookInTheCartException(NoBookInTheCartException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	

	
	@ExceptionHandler(value = BookIdDoesNotExistException.class)
	public ResponseEntity<Object> bookIdDoesNotExistException(BookIdDoesNotExistException e)
	{
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@Override
	public ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException e, HttpHeaders headers,
			HttpStatus status, WebRequest request) {

		return new ResponseEntity<>(e.getBindingResult().getAllErrors().get(0).getDefaultMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
}
